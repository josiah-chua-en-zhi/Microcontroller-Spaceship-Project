/*
 * Other_Functions.h
 *
 *  Created on: 24 Mar 2022
 *      Author: josia
 */
#include "Modes.h"
#include "main.h"

#ifndef SRC_OTHER_FUNCTIONS_H_
#define SRC_OTHER_FUNCTIONS_H_


//Functions for transmission to TermiNUS
void UART1_Init(void);
void transmit_to_TermiNUS(uint8_t* message);

//Constants for blinking LED
#define  DUTY_CYCLE_ON_25_PER       250
#define  DUTY_CYCLE_OFF_25_PER      750
#define  DUTY_CYCLE_ON_50_PER       500
#define  DUTY_CYCLE_OFF_50_PER      500
#define  DUTY_CYCLE_ON_75_PER       750
#define  DUTY_CYCLE_OFF_75_PER      250
#define  DUTY_CYCLE_ON_0_PER       	0
#define  DUTY_CYCLE_OFF_0_PER      	0
#define  FREQUENCY_1HZ       		1
#define  FREQUENCY_2HZ	    	  	2

//Functions for Change mode
typedef enum
{
TIMER_START,
TIMER_STOP
}WarningTimer_TypeDef;

typedef enum
{
BLINK_ON,
BLINK_OFF
}Current_State_TypeDef;

//Functions for blinking LED
int get_current_wait(void);
void update_Current_State(void);
Current_State_TypeDef get_LED_Current_State(void);
void change_duty_cycle(Mode_TypeDef mode);


uint32_t get_prev_time(void);
WarningTimer_TypeDef get_Warning_Timer(void);
void change_Warning_Mode_Timer(void);

//functions for stationary mode threshold
double get_wetbulb_temp (double T, double rh);
float float_terminal_override(void);


#endif /* SRC_OTHER_FUNCTIONS_H_ */
