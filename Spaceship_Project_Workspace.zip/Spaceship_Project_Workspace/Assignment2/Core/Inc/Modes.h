/*
 * Modes.h
 *
 *  Created on: 24 Mar 2022
 *      Author: josia
 */
#include "main.h"

#ifndef INC_MODES_H_
#define INC_MODES_H_

#define LSM6DSL_A_WRIST_TILT_MASK                     0x59
#define LSM6DSL_A_WRIST_TILT_LAT                      0x50
#define LSM6DSL_A_WRIST_TILT_THS                      0x54
#define LSM6DSL_ACC_GYRO_FUNC_SRC_TWO                 0x54

typedef enum
{
STATIONARY,
LAUNCH,
RETURN,
}Mode_TypeDef;

typedef enum
{
WARNING_ON,
WARNING_OFF,
}Warning_TypeDef;
typedef enum
{
FALSE,
TRUE,
}Boolean;

Mode_TypeDef get_Mode(void);
void update_Mode(void);
Warning_TypeDef get_Warning_Mode(void);
void update_Warning_Mode(void);
Mode_TypeDef get_Check_Mode(void);
void update_Check_Mode(void);
Boolean get_If_Count_Down(void);
void set_Count_Down(void);
void reset_Count_Down(void);
Boolean check_Door_Open(void);
Boolean check_prev_Door_Open(void);
void close_door(void);
void open_door(void);
Boolean check_Start_Door_Timer(void);
void update_Start_Door_Timer(void);
void update_prev_Door_Open(void);

void init_new_mode(Mode_TypeDef new_mode);
void Warning_Mode_Output(void);
void Stationary_Mode_Count_Down(void);
void Stationary_Mode_Readings(void);
void Launch_Return_Mode_Readings(void);

void Enable_AWT_Accelerometer(void);
void Set_Register(uint8_t Addr, uint8_t Reg, uint8_t Value);
void Reset_Register(uint8_t Addr, uint8_t Reg, uint8_t Value);

void Enable_Door_Sensor(void);

#endif /* INC_MODES_H_ */
